package com.secureops.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface TextMessageRepository extends MessageRepository {
}