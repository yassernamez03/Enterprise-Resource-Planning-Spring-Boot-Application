package com.secureops.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface FileMessageRepository extends MessageRepository {
}