package com.secureops.sales.entity;

public enum OrderStatus {
    PENDING,
    IN_PROCESS,
    COMPLETED,
    CANCELLED,
    INVOICED
}