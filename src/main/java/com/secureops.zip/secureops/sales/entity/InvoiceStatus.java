package com.secureops.sales.entity;

public enum InvoiceStatus {
    PENDING,
    PAID,
    OVERDUE,
    CANCELLED
}