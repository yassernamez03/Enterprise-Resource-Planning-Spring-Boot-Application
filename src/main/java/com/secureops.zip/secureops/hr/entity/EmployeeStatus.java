package com.secureops.hr.entity;

public enum EmployeeStatus {
    ACTIVE,
    ON_LEAVE,
    TERMINATED,
    PROBATION
}